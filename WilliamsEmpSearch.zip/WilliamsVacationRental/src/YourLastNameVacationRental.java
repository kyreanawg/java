import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.DefaultComboBoxModel;
import javax.swing.DefaultListSelectionModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;

public class YourLastNameVacationRental extends JFrame {

private static final long serialVersionUID = 1L;
private JPanel contentPane;
private JTextField showTotal;
private ImageIcon beachIcon;
private JLabel myLabel;


public static void main(String[] args) {
//starting the application window
EventQueue.invokeLater(new Runnable() {
public void run() {
try {
YourLastNameVacationRental frame = new YourLastNameVacationRental();
frame.setVisible(true);


} catch (Exception e) {
e.printStackTrace();
}
}
});
}


public YourLastNameVacationRental() {
//j panel info

	beachIcon= new ImageIcon(this.getClass().getResource("/beachh.png"));
	myLabel=new JLabel(beachIcon);
	myLabel.setSize(425, 439);
	contentPane = new JPanel();
	
setTitle("Vacation Rental");
setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
setBounds(100, 100, 425, 439);


contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
setContentPane(contentPane);
contentPane.setLayout(null);

//location comboBox info
JComboBox<String> locations = new JComboBox<>();
locations.setFont(new Font("Tahoma", Font.PLAIN, 13));
locations.setModel(new DefaultComboBoxModel<String>(new String[] { "Parkside", "Poolside", "Lakeside" }));
locations.setSelectedIndex(0);
locations.setBounds(229, 33, 96, 27);
contentPane.add(locations);

//location combo box label
JLabel lblNewLabel = new JLabel("Select Location:");
lblNewLabel.setLabelFor(locations);
lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 12));
lblNewLabel.setBounds(78, 35, 98, 20);
contentPane.add(lblNewLabel);

//no. of bedrooms combox info
JComboBox<String> bedrooms = new JComboBox<>();
bedrooms.setModel(new DefaultComboBoxModel<String>(new String[] { "1", "2", "3" }));
bedrooms.setSelectedIndex(0);
bedrooms.setFont(new Font("Tahoma", Font.PLAIN, 13));
bedrooms.setBounds(229, 93, 96, 27);
contentPane.add(bedrooms);

//no. of combo box label
JLabel lblSelectNumberOf = new JLabel("Number of Bedrooms:");
lblSelectNumberOf.setLabelFor(bedrooms);
lblSelectNumberOf.setFont(new Font("Tahoma", Font.BOLD, 12));
lblSelectNumberOf.setBounds(40, 95, 136, 20);
contentPane.add(lblSelectNumberOf);

//single selection mode list info
String values[] = { "Yes", "No" };
JList<String> list = new JList<>(values);
list.setFont(new Font("Tahoma", Font.PLAIN, 13));
list.setBounds(229, 147, 96, 40);
list.setSelectionMode(DefaultListSelectionModel.SINGLE_SELECTION);
contentPane.add(list);

//list label
JLabel lblMealIncluded = new JLabel("Meal Included:");
lblMealIncluded.setLabelFor(list);
lblMealIncluded.setFont(new Font("Tahoma", Font.BOLD, 12));
lblMealIncluded.setBounds(78, 153, 98, 20);
contentPane.add(lblMealIncluded);

//text field for showing total cost
showTotal = new JTextField();
showTotal.setFont(new Font("Tahoma", Font.BOLD, 15));
showTotal.setText("00.0$");
showTotal.setHorizontalAlignment(SwingConstants.CENTER);
showTotal.setEditable(false);
showTotal.setBounds(125, 234, 136, 41);
contentPane.add(showTotal);
showTotal.setColumns(10);

//button for performing cost calculation
JButton calculate = new JButton("Calculate");
calculate.addActionListener(new ActionListener() {
public void actionPerformed(ActionEvent arg0) {
double locationCost = getLocationPrice(locations.getSelectedItem() + "");
double bedroomCost = getBedroomPrice(Integer.parseInt(bedrooms.getSelectedItem() + ""));
double mealCost = getMealCost(list.getSelectedValue());
double total = locationCost + bedroomCost + mealCost;
showTotal.setText(total + "$");
}
});
calculate.setFont(new Font("Tahoma", Font.PLAIN, 13));
calculate.setBounds(138, 322, 109, 33);
contentPane.add(calculate);
contentPane.add(myLabel);

}

//for finding location cost
public double getLocationPrice(String location) {
double price = 0;

if (location.equals("Parkside"))
price = 700;
else if (location.equals("Poolside"))
price = 850;
else
price = 1025;

return price;
}

//for finding number of bedrooms cost
public double getBedroomPrice(int no) {
if (no == 1)
return 0;
else if (no == 2)
return 80;
else
return 160;
}

//for finding meal cost
public double getMealCost(String response) {
if (response.equals("Yes"))
return 200;
else
return 0;
}
}
