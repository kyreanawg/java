//Kyreana Williams
//WilliamsSalesTax
//Create a GUI application that allows 
//the user to enter the total sales for the month 
//into a text field.  From this amount, 
//the application should calculate and display 
//the following:county tax, state tax, tax total
//Due:Oct 22, 2023
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.text.NumberFormat;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class MonthlySales {
static final double countyTax =0.06;
static final double salesTax=0.075;
	public static void main(String[] args) {
		
		
		//create panel object
		JPanel panel = new JPanel();
		//create a frame
		//frame=window
		JFrame frame = new JFrame();
		frame.setSize(800, 200);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		
		//put panel on the frame
		frame.add(panel);
		//add layout 
		//panel=layout
		
		panel.setLayout(null);
		
		JLabel label = new JLabel("Monthly Sales Tax");
		label.setBounds(10, 20, 200, 25);
		panel.add(label);
		
		
	
		JLabel nlabel = new JLabel("Enter the total sales for the month");
		nlabel.setBounds(10, 60, 350, 25);
		panel.add(nlabel);
		
		//create text field for user input 
		JTextField input = new JTextField();
		input.setBounds(250, 60, 350, 25);
		panel.add(input);

		//create a button for conversions
		JButton calcCountyTax = new JButton("Calculate County Tax");
		calcCountyTax.setBounds(10, 130, 200, 25);
		panel.add(calcCountyTax);
		
		
		//MAKE COUNTY TAX BUTTON WORK
		calcCountyTax.addActionListener
		(
			new ActionListener() {
				public void actionPerformed(ActionEvent e)
				{
					
					
					//Convert sales to county tax 
					String countyTax1 = input.getText();
					double c= Double.parseDouble(countyTax1);
					double total1= c*countyTax;
					NumberFormat fmt = NumberFormat.getCurrencyInstance();
					input.setText(String.valueOf(fmt.format(total1)));
	
					
				}
			}
		);
		//no letters validation
		input.addKeyListener(new KeyAdapter() {
		    public void keyTyped(KeyEvent e) {
		        char c = e.getKeyChar();
		        if ( ((c < '0') || (c > '9')) && (c != KeyEvent.VK_BACK_SPACE)) {
		            e.consume();  // if it's not a number, ignore the event
		        }
		     }
		});
		
		JButton calcSalesTax = new JButton("Calculate Sales Tax");
		calcSalesTax.setBounds(200, 130, 200, 25);
		panel.add(calcSalesTax);
		
		//MAKE SALES TAX BUTTON WORK
		calcSalesTax.addActionListener
		(
			new ActionListener() {
				public void actionPerformed(ActionEvent e)
				{
					//Convert sales to county tax 
					String salesTax1 = input.getText();
					double b= Double.parseDouble(salesTax1);
					double total2= b*salesTax;
					input.setText(String.valueOf(total2));
                    NumberFormat fmt2 = NumberFormat.getCurrencyInstance();
					input.setText(String.valueOf(fmt2.format(total2)));
				}
			}
		);
		
		JButton calcTotalTax = new JButton("Calculate Total Sales Tax");
		calcTotalTax.setBounds(390, 130, 200, 25);
		panel.add(calcTotalTax);
		
		//MAKE SALES TAX BUTTON WORK
				calcTotalTax.addActionListener
				(
					new ActionListener() {
						public void actionPerformed(ActionEvent e)
						{
							//Convert sales to county tax 
							String totalTax1 = input.getText();
							double t= Double.parseDouble(totalTax1);
							double total3= t*salesTax;
							double total4= t*countyTax;
							double finalTotal= total3+total4;
							input.setText(String.valueOf(finalTotal));
							 NumberFormat fmt3 = NumberFormat.getCurrencyInstance();
								input.setText(String.valueOf(fmt3.format(finalTotal)));
						}
					}
				);
		
		
		frame.setVisible(true);
	}
	

}
