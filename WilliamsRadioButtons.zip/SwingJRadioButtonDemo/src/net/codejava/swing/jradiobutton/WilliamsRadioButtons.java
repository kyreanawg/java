package net.codejava.swing.jradiobutton;

import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JRadioButton;
import javax.swing.SwingUtilities;


 
public class WilliamsRadioButtons extends JFrame {



	private JRadioButton jaguarButton = new JRadioButton("Jaguar");
	private JRadioButton chickenButton = new JRadioButton("Chicken");
	private JRadioButton otherButton = new JRadioButton("Other");

	private JLabel labelImage = new JLabel();

	private ImageIcon iconJag= new ImageIcon(getClass().getResource(
			"/net/codejava/swing/jradiobutton/jag.png"));
	private ImageIcon iconChicken= new ImageIcon(getClass().getResource(
			"/net/codejava/swing/jradiobutton/chicken.png"));
	private ImageIcon iconOther = new ImageIcon(getClass().getResource(
			"/net/codejava/swing/jradiobutton/other.png"));

	public WilliamsRadioButtons() {
		super("Williams Radio Button Demo");

		ButtonGroup group = new ButtonGroup();
		group.add(jaguarButton);
		group.add(chickenButton);
		group.add(otherButton);

		chickenButton.setSelected(true);
		labelImage.setIcon(iconChicken);

		setLayout(new GridBagLayout());
		GridBagConstraints constraints = new GridBagConstraints();
		constraints.gridx = 0;
		constraints.gridy = 0;
		constraints.anchor = GridBagConstraints.CENTER;
		constraints.insets = new Insets(100, 10, 10, 10);

		add(jaguarButton, constraints);
		constraints.gridx = 1;
		add(chickenButton, constraints);
		constraints.gridx = 2;
		add(otherButton, constraints);

		constraints.gridx = 0;
		constraints.gridy = 1;
		constraints.gridwidth = 3;

		add(labelImage, constraints);

		constraints.gridy = 2;
		

		RadioButtonActionListener actionListener = new RadioButtonActionListener();
		jaguarButton.addActionListener(actionListener);
		chickenButton.addActionListener(actionListener);
		otherButton.addActionListener(actionListener);

		

		pack();
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLocationRelativeTo(null);
	}

	class RadioButtonActionListener implements ActionListener {
		@Override
		public void actionPerformed(ActionEvent event) {
			JRadioButton button = (JRadioButton) event.getSource();
			if (button == jaguarButton) {

				labelImage.setIcon(iconJag);

			} else if (button == chickenButton) {

				labelImage.setIcon(iconChicken);

			} else if (button == otherButton) {

				labelImage.setIcon(iconOther);
			}
		}
	}

	public static void main(String[] args) {
		SwingUtilities.invokeLater(new Runnable() {

			@Override
			public void run() {
				new WilliamsRadioButtons().setVisible(true);
			}
		});
	}
}